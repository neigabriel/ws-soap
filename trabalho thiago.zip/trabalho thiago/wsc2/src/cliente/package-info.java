@javax.xml.bind.annotation.XmlSchema(namespace = "http://controle/")
package cliente;
