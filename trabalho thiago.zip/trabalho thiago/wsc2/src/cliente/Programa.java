package cliente;

import java.util.Scanner;

public class Programa {
	public static void main(String[] args) {
		Conversor conversor = new ConversorService().getConversorPort();
		Scanner leia = new Scanner(System.in);
		System.out.print("Informe a distancia: ");
		double dist = leia.nextDouble();
		System.out.print("Escolha 1 para km e 2 para milha: ");
		int i = leia.nextInt();
		if (i == 1) {
			System.out.println("Resultado: " + conversor.converteParaKM(dist) + " KM" );
		} else if (i == 2) {

			System.out.println("Resultado: " + conversor.converteParaMilha(dist) + " milhas");
		}

		else {
			System.out.print("Opcao invalida");

		}
	   

	}

}
