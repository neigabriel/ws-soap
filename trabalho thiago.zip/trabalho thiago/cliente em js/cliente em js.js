const soap = require("soap");
const url = "http://localhost:10000/conversor?wsdl";
soap.createClient(url, function (err, client) {
  client.converteParaMilha({km : 50}, function (err, result) {
    console.log(result);
  });
});

