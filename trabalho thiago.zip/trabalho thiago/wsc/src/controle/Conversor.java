package controle;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

@WebService
public class Conversor {

	double valorKm = 1.609;
	double resultado = 0.0;

	@WebMethod
	public double converteParaKM(@WebParam(name = "milha") double milha) {
		resultado = valorKm * milha;
		return resultado;
	}

	@WebMethod
	public double converteParaMilha(@WebParam(name = "km") double km) {
		resultado = km / valorKm;
		return resultado;
	}
}
