
package controle.jaxws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "converteParaKM", namespace = "http://controle/")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "converteParaKM", namespace = "http://controle/")
public class ConverteParaKM {

    @XmlElement(name = "milha", namespace = "")
    private double milha;

    /**
     * 
     * @return
     *     returns double
     */
    public double getMilha() {
        return this.milha;
    }

    /**
     * 
     * @param milha
     *     the value for the milha property
     */
    public void setMilha(double milha) {
        this.milha = milha;
    }

}
